nvflash.exe --bl bootloader.bin --go -w
nvflash.exe -r --rawdevicewrite 0 533 u-boot.bct --go --sync
