nvflash --bct empty.bct --setbct --configfile flash.cfg --create --bl bootloader.bin --odmdata 0x800c0075 --go -w
