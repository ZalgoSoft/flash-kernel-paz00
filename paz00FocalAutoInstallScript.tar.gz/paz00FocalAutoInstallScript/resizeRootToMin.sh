#!/bin/bash

# Проверяем, что скрипт запущен от root
if [ "$(id -u)" -ne 0 ]; then
    echo "Этот скрипт должен быть запущен с правами root" >&2
    exit 1
fi

PARTITION="/dev/mmcblk0p1"
DEVICE="/dev/mmcblk0"

# Проверяем, что раздел существует
if [ ! -b "$PARTITION" ]; then
    echo "Раздел $PARTITION не найден!" >&2
    exit 1
fi

# Убедимся, что раздел не смонтирован
umount "$PARTITION" 2>/dev/null

# Проверяем файловую систему (ext4 предполагается)
echo "Проверка файловой системы на $PARTITION..."
e2fsck -f -y "$PARTITION"

# Определяем минимальный размер для файловой системы
echo "Определение минимального размера для файловой системы..."
MINSIZE=$(resize2fs -P "$PARTITION" 2>&1 | awk -F': ' '{print $2}')
BLOCK_SIZE=$(tune2fs -l "$PARTITION" | grep 'Block size' | awk '{print $3}')
MINSIZE_BYTES=$((MINSIZE * BLOCK_SIZE))
MINSIZE_SECTORS=$((MINSIZE_BYTES / 512))

# Получаем текущую информацию о разделе
PART_INFO=$(parted -m "$DEVICE" unit s print | grep "^1:")
START_SECTOR=$(echo "$PART_INFO" | cut -d':' -f2 | sed 's/s//g')
OLD_END_SECTOR=$(echo "$PART_INFO" | cut -d':' -f3 | sed 's/s//g')

# Рассчитываем новый конечный сектор
NEW_END_SECTOR=$((START_SECTOR + MINSIZE_SECTORS + 2048)) # Добавляем буфер в 1MB (2048 секторов)

# Изменяем размер файловой системы под новый размер раздела
echo "Изменение размера файловой системы..."
resize2fs -M "$PARTITION"

# Изменяем размер раздела
echo "Изменение размера раздела..."
parted "$DEVICE" resizepart 1 "$NEW_END_SECTOR"s

e2fsck -f -y "$PARTITION"

echo "Готово! Раздел $PARTITION был уменьшен до минимального размера."
