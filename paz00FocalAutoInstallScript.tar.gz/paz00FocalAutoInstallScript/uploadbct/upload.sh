dd if=/dev/mmcblk1boot0 of=current.bct bs=4080 count=1
cbootimage -d u-boot.cfg u-boot.bct
echo "0" > /sys/block/mmcblk1boot0/force_ro
dd if=u-boot.bct of=/dev/mmcblk1boot0

