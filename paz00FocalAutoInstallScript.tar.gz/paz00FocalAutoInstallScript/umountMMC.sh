#!/bin/bash
# Устройство для установки (внешняя MMC)
DEVICE="/dev/mmcblk0"
ROOT_PART="${DEVICE}p1"

# Завершение установки
echo "Завершение установки..."

if mountpoint -q /mnt/ubuntu/boot/efi; then umount /mnt/ubuntu/boot/efi; fi
if mountpoint -q /mnt/ubuntu/dev/pts; then umount /mnt/ubuntu/dev/pts; fi
if mountpoint -q /mnt/ubuntu/dev/pts; then umount /mnt/ubuntu/dev/pts; fi
if mountpoint -q /mnt/ubuntu/dev; then umount /mnt/ubuntu/dev; fi
if mountpoint -q /mnt/ubuntu/proc; then umount /mnt/ubuntu/proc; fi
if mountpoint -q /mnt/ubuntu/sys; then umount /mnt/ubuntu/sys; fi
if mountpoint -q /mnt/ubuntu/run; then umount /mnt/ubuntu/run; fi
if mountpoint -q /mnt/ubuntu; then echo "Размонтирование /mnt/ubuntu..." ; umount /mnt/ubuntu; fi



sync

echo "Установка завершена! Вы можете загрузиться с внешней MMC."

