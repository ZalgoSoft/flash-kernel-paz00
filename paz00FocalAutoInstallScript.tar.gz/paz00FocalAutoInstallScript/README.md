Script installs on extermal MMC minimal Ubuntu Focal using official net image as base. Also adds some thunings AC100 related.

Additional scripts there:
1. shrinks partition
2. script which umounts installed MMC
3. update BCT with fresh U-BOOT 2025.04 for PAZ00


How it works

1. Downloads image https://cdimage.ubuntu.com/ubuntu-base/releases/20.04/release/ubuntu-base-20.04.5-base-armhf.tar.gz
2. Repartitioning /dev/mmcblk0 , adds only single partition p1 ext4
3. extracts ubuntu-base
4. in chroot basic configuring console, timezone and locale
5. in chroot apt-get installing some packages in some stages to avoid conflicts
6. copy configs to instance
7. update initramfs and generate extlinux.conf
8. Not unmounting partitions, for you may add some changes to build
9. Exits

Script has features:
1. check execution for errors and exits on error
2. verbosity execution of steps
3. check if image and packages were retreived earlier and backuping - restore local copies them, useful for local debugging and add changes to script
4. image is boot-ready for u-boot extlinux way
5. Now it runs only from same AC100, not PC 

