#!/bin/bash


set -eo pipefail
trap 'error_handler $? $LINENO' ERR

error_handler() {
    local exit_code=$1
    local line_no=$2
    echo -e "\n[ОШИБКА] Ошибка в строке $line_no с кодом $exit_code"
    read -p "Продолжить выполнение? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Прерывание выполнения скрипта"
        exit $exit_code
    fi
}

total_commands=$(grep -v '^[[:space:]]*#' $0 | grep -cvE '^[[:space:]]*$')
current_command=0

trap 'current_command=$((current_command + 1)); \
      echo -n "[$((100 * current_command / total_commands))%] "; \
      echo "Выполняю команду $current_command/$total_commands"' DEBUG


# Проверка на root
if [ "$(id -u)" -ne 0 ]; then
  echo "Этот скрипт должен запускаться с правами root" >&2
  exit 1
fi

# Устройство для установки (внешняя MMC)
DEVICE="/dev/mmcblk0"
ROOT_PART="${DEVICE}p1"

APT_CACHE_DIR="/tmp/apt-cache"
APT_STATE_DIR="/tmp/apt-state"

# URL для Ubuntu Base
UBUNTU_BASE_URL="https://cdimage.ubuntu.com/ubuntu-base/releases/20.04/release/ubuntu-base-20.04.5-base-armhf.tar.gz"



# Добавить в начало скрипта (после проверки root):
# Проверка и размонтирование если уже смонтировано

if mountpoint -q /mnt/ubuntu; then

# Изменения в блоке сохранения кэша (перед размонтированием):
echo "Проверка и сохранение кэша APT..."
if [ -d "/mnt/ubuntu/var/cache/apt/archives" ] && [ "$(ls -A /mnt/ubuntu/var/cache/apt/archives)" ]; then
    echo "Сохранение кэша .deb пакетов..."
#    rm -rf ${APT_CACHE_DIR}
    mkdir -p ${APT_CACHE_DIR}
    rsync -a --delete /mnt/ubuntu/var/cache/apt/archives/ ${APT_CACHE_DIR}/
else
    echo "Нет .deb пакетов для сохранения в кэше"
fi

if [ -d "/mnt/ubuntu/var/lib/apt/lists" ] && [ "$(ls -A /mnt/ubuntu/var/lib/apt/lists)" ]; then
    echo "Сохранение списков репозиториев..."
#    rm -rf ${APT_STATE_DIR}
    mkdir -p ${APT_STATE_DIR}
    rsync -a --delete /mnt/ubuntu/var/lib/apt/lists/ ${APT_STATE_DIR}/
else
    echo "Нет списков репозиториев для сохранения"
fi

# Модифицировать блок после выхода из chroot:
if mountpoint -q /mnt/ubuntu/dev/pts; then umount /mnt/ubuntu/dev/pts; fi
if mountpoint -q /mnt/ubuntu/dev/pts; then umount /mnt/ubuntu/dev/pts; fi

if mountpoint -q /mnt/ubuntu/dev; then umount /mnt/ubuntu/dev; fi
if mountpoint -q /mnt/ubuntu/proc; then umount /mnt/ubuntu/proc; fi
if mountpoint -q /mnt/ubuntu/sys; then umount /mnt/ubuntu/sys; fi
if mountpoint -q /mnt/ubuntu/run; then umount /mnt/ubuntu/run; fi

    echo "Размонтирование /mnt/ubuntu..."
    umount /mnt/ubuntu
fi

# 1. Создание разделов
echo "Создание разделов на ${DEVICE}..."
echo "Очистка существующей таблицы разделов..."
wipefs -a ${DEVICE}
parted -s "${DEVICE}" mklabel gpt
parted -s "${DEVICE}" mkpart primary ext4 2048s 3GiB
sync
sleep 3
sync

# 2. Форматирование разделов
echo "Форматирование разделов..."
mkfs.ext4 -F "${ROOT_PART}"

# 3. Монтирование и установка системы
echo "Монтирование и установка системы..."
mkdir -p /mnt/ubuntu
mount "${ROOT_PART}" /mnt/ubuntu

echo "Проверка наличия Ubuntu Base..."
UBUNTU_BASE_FILE="/tmp/$(basename ${UBUNTU_BASE_URL})"
if [ ! -f "${UBUNTU_BASE_FILE}" ]; then
    echo "Загрузка Ubuntu Base..."
    wget "${UBUNTU_BASE_URL}" -O "${UBUNTU_BASE_FILE}"
else
    echo "Файл уже скачан, используем существующий: ${UBUNTU_BASE_FILE}"
fi

echo "Распаковка Ubuntu Base..."
tar -xzf "${UBUNTU_BASE_FILE}" -C /mnt/ubuntu
# 4. Настройка базовой системы
echo "Настройка базовой системы..."
mount -t proc proc /mnt/ubuntu/proc
mount -t sysfs sys /mnt/ubuntu/sys
mount -o bind /dev /mnt/ubuntu/dev
mount -t devpts devpts /mnt/ubuntu/dev/pts -o gid=5,mode=620
mount -o bind /run /mnt/ubuntu/run
chroot /mnt/ubuntu /bin/bash -c "mkdir -p /dev/pts && mount -t devpts devpts /dev/pts"
#chroot /mnt/ubuntu /bin/bash -c "mknod -m 666 /dev/null c 1 3"
#chroot /mnt/ubuntu /bin/bash -c "mknod -m 666 /dev/zero c 1 5"
#chroot /mnt/ubuntu /bin/bash -c "mknod -m 666 /dev/random c 1 8"
#chroot /mnt/ubuntu /bin/bash -c "mknod -m 666 /dev/urandom c 1 9"

# Создание fstab
echo "Создание /etc/fstab..."
cat > /mnt/ubuntu/etc/fstab << EOF
# <file system> <mount point>   <type>  <options>       <dump>  <pass>
${ROOT_PART}  /               ext4    errors=remount-ro 0       1
EOF

# Добавить после распаковки Ubuntu Base (перед chroot):
# Копирование resolv.conf для работы сети в chroot
echo "Настройка resolv.conf..."
mkdir -p /mnt/ubuntu/etc
cp /etc/resolv.conf /mnt/ubuntu/etc/resolv.conf



# Изменения в блоке восстановления кэша (в chroot-секции):
echo "Проверка и восстановление кэша APT..."
if [ -d "${APT_CACHE_DIR}" ] && [ "$(ls -A ${APT_CACHE_DIR})" ]; then
    echo "Восстановление .deb пакетов из кэша..."
    mkdir -p /mnt/ubuntu/var/cache/apt/archives
    rsync -a ${APT_CACHE_DIR}/ /mnt/ubuntu/var/cache/apt/archives/
else
    echo "Нет .deb пакетов для восстановления из кэша"
fi

if [ -d "${APT_STATE_DIR}" ] && [ "$(ls -A ${APT_STATE_DIR})" ]; then
    echo "Восстановление списков репозиториев из кэша..."
    mkdir -p /mnt/ubuntu/var/lib/apt/lists
    rsync -a ${APT_STATE_DIR}/ /mnt/ubuntu/var/lib/apt/lists/
else
    echo "Нет списков репозиториев для восстановления из кэша"
fi

echo "Настройка локалей..."
cat > /mnt/ubuntu/etc/locale.gen << EOF
en_US.UTF-8 UTF-8
ru_RU.UTF-8 UTF-8
EOF

# 5. Установка базовых пакетов и настройка
chroot /mnt/ubuntu env total_commands=$total_commands current_command=$current_command /bin/bash -x <<EOF

trap 'current_command=$((current_command + 1)); \
      echo -n "[$((100 * current_command / total_commands))%] "; \
      echo "Выполняю команду $current_command/$total_commands"' DEBUG


unset LANG LANGUAGE LC_ALL LC_CTYPE LC_NUMERIC LC_TIME LC_COLLATE LC_MONETARY LC_MESSAGES LC_PAPER LC_NAME LC_ADDRESS LC_TELEPHONE LC_MEASUREMENT LC_IDENTIFICATION
export LANG=C
export LC_ALL=C
apt-get update

# Настройка локали и часового пояса
echo "locales locales/locales_to_be_generated multiselect en_US.UTF-8 UTF-8, ru_RU.UTF-8 UTF-8" | debconf-set-selections
echo "locales locales/default_environment_locale select C.UTF-8" | debconf-set-selections
echo "tzdata tzdata/Areas select Asia" | debconf-set-selections
echo "tzdata tzdata/Zones/Asia select Irkutsk" | debconf-set-selections
echo "console-setup console-setup/guess_font boolean false" | debconf-set-selections
echo "console-setup console-setup/framebuffer_only boolean false" | debconf-set-selections
echo "console-setup console-setup/fontface47 select Fixed" | debconf-set-selections
echo "console-setup console-setup/charmap47 select UTF-8" | debconf-set-selections
echo "console-setup console-setup/fontsize-text47 select 8x16" | debconf-set-selections
echo "console-setup console-setup/codeset47 select . Combined - Latin; Slavic Cyrillic; Greek" | debconf-set-selections
echo "console-setup console-setup/fontsize-fb47 select 8x16" | debconf-set-selections
echo "console-setup console-setup/use_system_font boolean false" | debconf-set-selections
echo "console-setup console-setup/fontsize select 8x16" | debconf-set-selections
echo "console-setup console-setup/codesetcode select Uni2" | debconf-set-selections
echo "console-setup console-setup/store_defaults_in_debconf_db boolean true" | debconf-set-selections

apt-get install -y dialog
DEBIAN_FRONTEND=noninteractive apt-get install -y tzdata 
apt-get install -y locales 
update-locale LANG=ru_RU.UTF-8 LANGUAGE=ru_RU:ru LC_ALL=ru_RU.UTF-8
#echo "Asia/Irkutsk" > /etc/timezone
#ln -fs /usr/share/zoneinfo/Asia/Irkutsk /etc/localtime
#dpkg-reconfigure -f noninteractive tzdata

#DEBIAN_FRONTEND=noninteractive 
apt-get install -y --reinstall systemd
DEBIAN_FRONTEND=noninteractive apt-get install -y --reinstall kmod console-setup


# Установка основных пакетов
apt-get install -y ubuntu-minimal linux-image-generic initramfs-tools \
  network-manager wpasupplicant wireless-tools \
  sudo bash-completion openssh-server u-boot-tools u-boot-menu cbootimage vim-tiny

apt-get remove -y --purge flash-kernel

# Настройка сети
echo "ac100" > /etc/hostname
cat > /etc/hosts << EOH
127.0.0.1   localhost
127.0.1.1   ac100
EOH

# Настройка пользователя
echo "Введите пароль для пользователя user1:"
useradd -m -G sudo -s /bin/bash user1
echo "user1:1" | sudo chpasswd
EOF

cp ./initramfs.conf /mnt/ubuntu/etc/initramfs-tools/
cp ./modules /mnt/ubuntu/etc/initramfs-tools/
cp ./u-boot /mnt/ubuntu/etc/default/
cp ./rc.local /mnt/ubuntu/etc/
cp ./fw_env.config /mnt/ubuntu/etc/

chroot /mnt/ubuntu env total_commands=$total_commands current_command=$current_command /bin/bash -x <<EOF

trap 'current_command=$((current_command + 1)); \
      echo -n "[$((100 * current_command / total_commands))%] "; \
      echo "Выполняю команду $current_command/$total_commands"' DEBUG

update-initramfs -k `ls /boot/vmlinuz-* | sed 's|/boot/vmlinuz-||'` -c -v
u-boot-update

EOF

#trap - ERROR

# Убираем перехватчик
#trap - DEBUG

# Финальное сообщение
tput cup $((LINES - 1)) 0
tput el
echo "Скрипт завершен! Всего выполнено $TOTAL_COMMANDS команд."

