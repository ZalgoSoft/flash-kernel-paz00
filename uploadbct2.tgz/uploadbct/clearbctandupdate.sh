[ -e /dev/mmcblk0boot0 ] && mmc=mmcblk0boot0 || mmc=mmcblk1boot0 
dd if=/dev/$mmc of=current.bct bs=4080 count=1
bct_dump current.bct > current.bct.cfg
cbootimage -d -gbct -o 0x800c0075 -t 20 -s tegra20 current.bct.cfg empty.bct
cbootimage -d u-boot.empty.cfg u-boot.bct
echo "0" > /sys/block/$mmc/force_ro
dd if=u-boot.bct of=/dev/$mmc


