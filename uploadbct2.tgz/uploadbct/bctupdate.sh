[ -e /dev/mmcblk0boot0 ] && mmc=mmcblk0boot0 || mmc=mmcblk1boot0 
dd if=/dev/$mmc of=current.bct bs=4080 count=1
cbootimage -d u-boot.cfg u-boot.bct
echo "0" > /sys/block/$mmc/force_ro
dd if=u-boot.bct of=/dev/$mmc

