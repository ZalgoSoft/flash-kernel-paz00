Download and extract the sample arm-generic filesystem to this directory.
