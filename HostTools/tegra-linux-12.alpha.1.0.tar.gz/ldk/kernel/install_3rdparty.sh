#!/bin/bash

#
# Install 3rd party software used by other scripts.
# Installation happens only once, even if the script is run multiple times.
#
# The following will be installed:
# - Sourcery G++ Lite 2009q1-203 for ARM GNU/Linux
#
# Optional environment variables:
#
# SOURCERY_ROOT     points to an existing Sourcery G++ Lite installation,
#                   Sourcery installation skipped if set
#
# Usage: install_3rdparty.sh
#

TOP=$PWD

if [ -n "$SOURCERY_ROOT" ]; then
    echo "SOURCERY_ROOT is set. Skipping installation."
else
    SOURCERY_ROOT=$PWD/arm-2009q1

    mkdir -p _out/3rdparty
    cd _out/3rdparty

    if [ -f installed_sourcery ]
    then
        echo "Sourcery G++ Lite already installed."
    else
        echo "Downloading and installing Sourcery G++ Lite."
        wget http://www.codesourcery.com/sgpp/lite/arm/portal/package4571/public/arm-none-linux-gnueabi/arm-2009q1-203-arm-none-linux-gnueabi-i686-pc-linux-gnu.tar.bz2
        tar xvjf arm-2009q1-203-arm-none-linux-gnueabi-i686-pc-linux-gnu.tar.bz2
        echo $SOURCERY_ROOT >> installed_sourcery
    fi
    
    cd "$TOP"
fi

echo "Completed."
