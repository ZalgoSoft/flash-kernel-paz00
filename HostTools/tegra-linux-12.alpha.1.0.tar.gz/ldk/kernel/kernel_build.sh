#!/bin/bash

#
# This script builds the kernel that was sync'ed with kernel_sync.sh script
#

# fail on errors
set -e

TOOLCHAIN=arm-none-linux-gnueabi-
LDK_KERNEL_DIR=$(cd `dirname $0` && pwd)

if [ -n "$SOURCERY_ROOT" ]; then
    PATH=${PATH}:"${SOURCERY_ROOT}/bin/"
else
    PATH=${PATH}:"${LDK_KERNEL_DIR}/_out/3rdparty/arm-2009q1/bin/"
fi

cd ${LDK_KERNEL_DIR}/kernel
chromeos/scripts/prepareconfig chromeos-tegra2
make ARCH=arm CROSS_COMPILE=${TOOLCHAIN} oldconfig
make ARCH=arm CROSS_COMPILE=${TOOLCHAIN}
# if making modules the next commands are needed
make ARCH=arm CROSS_COMPILE=${TOOLCHAIN} modules
DESTDIR=./modules_install make ARCH=arm CROSS_COMPILE=${TOOLCHAIN} modules_install INSTALL_MOD_PATH=./modules_install
cd -

echo ""
echo "Kernel built successfully!"
