#!/bin/bash

#
# This script sync's the ChromiumOS kernel sources to the exact commit
# ID that the binary kernel shipped was built from. This allows you to
# replicate the exact kernel build.
#


# fail on errors
set -e

# verify that git is installed
if  ! which git > /dev/null  ; then
  echo "ERROR: git is not installed. If your linux distro is 10.04 or later,"
  echo "git can be installed by 'sudo apt-get install git-core'."
  exit
fi

LDK_KERNEL_CANGEID=1ac51794ea52c384dbb637892dd3c9629143a365
LDK_KERNEL_DIR=$(cd `dirname $0` && pwd)

if [ -d ${LDK_KERNEL_DIR}/kernel ] ; then
    echo "ERROR: ${LDK_KERNEL_DIR}/kernel already exists!"
    exit
fi

git clone http://git.chromium.org/chromiumos/third_party/kernel.git ${LDK_KERNEL_DIR}/kernel

cd ${LDK_KERNEL_DIR}/kernel
git checkout -b mybranch_$(date +%Y-%m-%d) ${LDK_KERNEL_CANGEID}
cd -

echo ""
echo "Kernel sources sync'ed successfully!"
