#!/bin/bash

#
# This installs the specific X abi version into the rootfs dir pointed to by
# LDK_ROOTFS_DIR variable.
#

# fail on errors
set -e

LDK_DIR=$(cd `dirname $0` && pwd)

# use default rootfs dir if none is set
if [ -z "${LDK_ROOTFS_DIR}" ] ; then
    LDK_ROOTFS_DIR=${LDK_DIR}/rootfs
    echo "Using default rootfs directory of: ${LDK_ROOTFS_DIR}"
    echo ""
fi

# verify first parameter is not blank
if [ -z "$1" ] ; then
    echo "Please pass in the ABI version number you would like installed in the rootfs."
    echo "For example, to install ABI version 5:"
    echo "./`basename $0` 5"
    exit
fi

# verify they passed in a correct ABI version
if [ "$1" != "5" -a "$1" != "6" -a "$1" != "7" -a "$1" != "8" -a "$1" != "10" ] ; then
    echo "ERROR: The ABI version specified is incorrect. Use either 5, 6, 7, 8, or 10."
    exit
fi

echo "Installing X ABI version $1 into ${LDK_ROOTFS_DIR}"

echo "Extracting the NVIDIA user space components to ${LDK_ROOTFS_DIR}"
pushd ${LDK_ROOTFS_DIR}
sudo tar xjf ${LDK_DIR}/nv_tegra/tegra-drivers-abi$1.tbz2
popd > /dev/null

echo "Success!"
