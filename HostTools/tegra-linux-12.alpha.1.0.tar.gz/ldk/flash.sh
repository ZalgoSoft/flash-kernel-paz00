#!/bin/bash
LDK_DIR=$(cd `dirname $0` && pwd)
#
# Flash the target board.
#
# Usage:
#	Place the board in recovery mode and run:
#	flash.sh <root_device>
#
# Where root_device is one of:
#   for harmony:
#	- mmcblk0p1: external sdcard
#	- sda1: USB disk or memory stick.
#   for ventana:
#	- mmcblk0p1: internal eMMC device
#	- mmcblk1p1: external sdcard
#	- sda1: USB disk or memory stick.
#
# Optional Environment Variables:
# ROOTFS_SIZE ------------ Linux RootFS size (internal emmc/nand only).
# ODMDATA ---------------- Odmdata to be used.
# BOOTLOADER ------------- Bootloader binary to be falshed
# BCTFILE ---------------- BCT file to be used.
# CFGFILE ---------------- CFG file to be used.
# KERNEL_IMAGE ----------- Linux kernel zImage file to be flashed.
# KERNEL_BINARY_TGZ ------ Initrd file to be flashed.
# ROOTFS_TGZ ------------- Linux RootFS .tgz file.
# TEGRA_BINARIES_TGZ ----- Tegra binary tgz file.
# TEGRA_XABI_TBZ --------- Suggested XABI binary .tbz2 file.
# TEGRA_XORG_CONF -------- xorg.conf file to replace default.
# KERNEL_INITRD ---------- Initrd file to be flashed.
# CMDLINE ---------------- Target cmdline.
#
target_board=
target_rootdev=
internal_rootdev=
rootfs_size=${ROOTFS_SIZE};
odmdata=${ODMDATA};
bootloader=${BOOTLOADER};
bctfile=${BCTFILE};
cfgfile=${CFGFILE};
kernel_image=${KERNEL_IMAGE-${LDK_DIR}/kernel/zImage};
rootfs_tgz=${ROOTFS_TGZ-${LDK_DIR}/rootfs/sample_fs_natty.tgz};
kernel_binary_tgz=${KERNEL_BINARY_TGZ-${LDK_DIR}/kernel/kernel_binary.tar.gz};
tegra_binaries_tgz=${TEGRA_BINARIES_TGZ-${LDK_DIR}/nv_tegra/tegra_bins.tar.gz};
tegra_xabi_tbz=${TEGRA_XABI_TBZ-${LDK_DIR}/nv_tegra/tegra-drivers-abi10.tbz2};
tegra_xorg_conf=${TEGRA_XORG_CONF-${LDK_DIR}/nv_tegra/xorg.conf};
kernel_initrd=${KERNEL_INITRD};
cmdline=${CMDLINE};
zflag="false";

pr_conf()
{
	echo "target_board=${target_board}";
	echo "target_rootdev=${target_rootdev}";
	echo "internal_rootdev=${internal_rootdev}";
	echo "rootfs_size=${rootfs_size}";
	echo "odmdata=${odmdata}";
	echo "bootloader=${bootloader}";
	echo "bctfile=${bctfile}";
	echo "cfgfile=${cfgfile}";
	echo "kernel_image=${kernel_image}";
	echo "rootfs_tgz=${rootfs_tgz}";
	echo "kernel_binary_tgz=${kernel_binary_tgz}";
	echo "tegra_binaries_tgz=${tegra_binaries_tgz}";
	echo "tegra_xabi_tbz=${tegra_xabi_tbz}";
	echo "tegra_xorg_conf=${tegra_xorg_conf}";
	echo "kernel_initrd=${kernel_initrd}";
	echo "cmdline=${cmdline}";
	exit 0;
}

usage ()
{
cat << EOF
Usage: sudo ./flash.sh [options] <target board> <rootdev>

   Where <target board> is harmony or ventana and <rootdev> is one of following:
       mmcblk0p1 -- internal eMMC for ventana or external SDCARD for harmony.
       mmcblk1p1 -- external SDCARD for ventana.
       sda1 ------- external USB devices. (USB memory stick, HDD)

   options:
   -h ------------------- print this message.
   -b <bctfile> --------- nvflash BCT file.
   -c <cfgfile> --------- nvflash config file.
   -o <odmdata> --------- ODM data.
                          harmony: 0x302d8011 (default) 
                                   (This sets HDMI as primary display.)
                          ventana: 0x300d8011
                          cardhu:  0x80080105
   -L <bootloader> ------ Bootloader such as fastboot.bin
   -C <cmdline> --------- Kernel commandline.
                          WARNING:
                          This manual kernel commandline should be *FULL SET*.
                          Upon detecting manual commandline, bootloader override
                          entire kernel commandline with this <cmdline> input.
   -K <kernel> ---------- Kernel image such as zImage.
   -I <initrd> ---------- initrd file. Null initrd is default.
   -R <rootfs> ---------- Sample rootfs tgz file.
   -S <size> ------------ Rootfs size in bytes.(valid only for internal rootdev)
   -B <tegra binary> ---- tegra binary tgz file.
   -X <xabi tgz> -------- xabi tbz2 file.
   -O <xrog.conf file> -- xorg.conf file to override default.
   -Z ------------------- Show variables.

EOF
	exit $1;
}

while getopts "hb:c:o:L:C:K:I:R:S:B:X:O:Z" OPTION
do
	case $OPTION in
	h) usage 0;
	   ;;
	b) bctfile=${OPTARG};
	   ;;
	c) cfgfile=${OPTARG};
	   ;;
	o) odmdata=${OPTARG};
	   ;;
	L) bootloader=${OPTARG};
	   ;;
	C) cmdline=${OPTARG};
	   ;;
	K) kernel_image=${OPTARG};
	   ;;
	I) kernel_initrd=${OPTARG};
	   ;;
	R) rootfs_tgz=${OPTARG};
	   ;;
	S) rootfs_size=${OPTARG};
	   ;;
	B) tegra_binaries_tgz=${OPTARG};
	   ;;
	X) tegra_xabi_tbz=${OPTARG};
	   ;;
	O) tegra_xorg_conf=${OPTARG};
	   ;;
	Z) zflag="true";
	   ;;
	?) usage 1;
	   ;;
	esac
done
shift $((OPTIND - 1));
if [ $# -lt 2 ]; then
	usage 1;
fi;
target_board=$1;
target_rootdev=$2;

if [ "${target_board}" = "harmony" ]; then
	if [ "${target_rootdev}" != "mmcblk0p1" -a \
	       "${target_rootdev}" != "sda1" ]; then
		echo "Error: Invalid target rootdev($target_rootdev).";
		usage 1;
	fi;
	if [ "${rootfs_size}" = "" ]; then
		rootfs_size=471859200;
	fi;
	if [ "${odmdata}" = "" ]; then
		odmdata=0x302d8011;
	fi;
	if [ "${bctfile}" = "" ]; then
		bctfile=${LDK_DIR}/bootloader/${target_board}/BCT/harmony_a02_12Mhz_H5PS1G83EFR-S6C_333Mhz_1GB_2K8Nand_HY27UF084G2B-TP.bct;
	fi;
	if [ "${cfgfile}" = "" ]; then
		cfgfile=${LDK_DIR}/bootloader/${target_board}/cfg/gnu_linux_fastboot_nand_flashboot_full.cfg
	fi;
	if [ "x${cmdline}" == "x" ]; then
		cmdline="mem=384M@0M nvmem=128M@384M mem=512M@512M vmalloc=192M video=tegrafb console=ttyS0,115200n8 usbcore.old_scheme_first=1 root=/dev/${target_rootdev} rw rootwait earlyprintk loglevel=7"
	fi
elif [ "${target_board}" = ventana ]; then
        if [[ "${target_rootdev}" == mmcblk0* ]]; then
		internal_rootdev="true";
	elif [ "${target_rootdev}" != "mmcblk1p1" -a \
	       "${target_rootdev}" != "sda1" ]; then
		echo "Error: Invalid target rootdev($target_rootdev).";
		usage 1;
	fi;
	if [ "${rootfs_size}" = "" ]; then
		rootfs_size=1073741824;
	fi;
	if [ "${odmdata}" = "" ]; then
		odmdata=0x300d8011;
	fi;
	if [ "${bctfile}" = "" ]; then
		bctfile=${LDK_DIR}/bootloader/${target_board}/BCT/ventana_A03_12MHz_EDB8132B1PB6DF_300Mhz_1GB_emmc_THGBM1G6D4EBAI4.bct;
	fi;
	if [ "${cfgfile}" = "" ]; then
		cfgfile=${LDK_DIR}/bootloader/${target_board}/cfg/gnu_linux_fastboot_emmc_full.cfg;
	fi;
else
	echo "Error: Invalid target board."
	usage 1
fi

if [ "${bootloader}" = "" ]; then
	bootloader=${LDK_DIR}/bootloader/${target_board}/fastboot.bin;
fi;
if [ "${zflag}" = "true" ]; then
	pr_conf ;
	exit 0;
fi;

if [ ! -f $bootloader ]; then
	echo "Error: missing bootloader($bootloader).";
	usage 1;
fi;
if [ ! -f $bctfile ]; then
	echo "Error: missing BCT file($bctfile).";
	usage 1;
fi;
if [ ! -f $cfgfile ]; then
	echo "Error: missing config file($cfgfile).";
	usage 1;
fi;
if [ ! -f "${kernel_image}" ]; then
	echo "Error: missing kernel image file($kernel_image).";
	usage 1;
fi;

nvflashfolder=${LDK_DIR}/bootloader;
if [ ! -d $nvflashfolder ]; then
	echo "Error: missing nvflash folder($nfvlashfolder).";
	usage 1;
fi;
pushd $nvflashfolder > /dev/null 2>&1;
if [ "${internal_rootdev}" = "true" ]; then
	if [ -z "${rootfs_tgz}" -o ! -f "${rootfs_tgz}" ]; then
		echo "Error: missing rootfs($rootfs_tgz).";
		usage 1;
	fi;
	echo "Making system.img... ";
	umount /dev/loop0 > /dev/null 2>&1;
	losetup -d /dev/loop0 > /dev/null 2>&1;
	rm -f system.img;
	if [ $? -ne 0 ]; then
		echo "clearing system.img failed.";
		exit 1;
	fi;
	bcnt=$((${rootfs_size} / 512 ));
	dd if=/dev/zero of=system.img bs=512 count=$bcnt > /dev/null 2>&1;
	if [ $? -ne 0 ]; then
		echo "making system.img failed.";
		exit 1;
	fi;
	losetup /dev/loop0 system.img > /dev/null 2>&1;
	if [ $? -ne 0 ]; then
		echo "mapping system.img to loop device failed.";
		exit 1;
	fi;
	mkfs -t ext3 /dev/loop0 > /dev/null 2>&1;
	if [ $? -ne 0 ]; then
		echo "formating filesystem on system.img failed.";
		exit 1;
	fi;
	sync;
	rm -rf mnt;
	if [ $? -ne 0 ]; then
		echo "clearing mount point failed.";
		exit 1;
	fi;
	mkdir -p mnt;
	if [ $? -ne 0 ]; then
		echo "making mount point failed.";
		exit 1;
	fi;
	mount /dev/loop0 mnt > /dev/null 2>&1;
	if [ $? -ne 0 ]; then
		echo "mounting system.img failed.";
		exit 1;
	fi;
	pushd mnt > /dev/null 2>&1;
	echo -n -e "\tpopulating rootfs(${rootfs_tgz})... ";
	tar xzf ${rootfs_tgz} > /dev/null 2>&1;
	if [ $? -ne 0 ]; then
		echo "failed.";
		exit 1;
	fi;
	echo "done.";
	if [ -f ${kernel_binary_tgz} ]; then
		echo -e -n "\tpopulating kernel modules(${kernel_binary_tgz})... ";
		tar xzf ${kernel_binary_tgz} > /dev/null 2>&1;
		if [ $? -ne 0 ]; then
			echo "failed.";
			exit 1;
		fi;
		rm -f zImage > /dev/null 2>&1;	# Paranoid.
		echo "done.";
	else
		echo -e "\tkernel modules(${kernel_binary_tgz}) not found. continue.";
	fi;
	if [ -f ${tegra_binaries_tgz} ]; then
		echo -e -n "\tpopulating tegra binaries(${tegra_binaries_tgz})... ";
		tar xzf ${tegra_binaries_tgz} > /dev/null 2>&1;
		if [ $? -ne 0 ]; then
			echo "failed.";
			exit 1;
		fi;
		echo "done.";
	else
		echo -e "\ttegra binaries(${tegra_binaries_tgz}) not found. continue.";
	fi;
	if [ -f ${tegra_xabi_tbz} ]; then
		echo -e -n "\tpopulating X drivers(${tegra_xabi_tbz})... ";
		tar xjf ${tegra_xabi_tbz};
		if [ $? -ne 0 ]; then
			echo "failed.";
			exit 1;
		fi;
		echo "done.";
	else
		echo -e "\tX drivers(${tegra_xabi_tbz}) not found. continue ";
	fi;
	if [ -f ${tegra_xorg_conf} ]; then
		echo -e -n "\tpopulating optional xorg.conf(${tegra_xorg_conf})... ";
		cp -f ${tegra_xorg_conf} etc/X11;
		if [ $? -ne 0 ]; then
			echo "failed.";
			exit 1;
		fi;
		echo "done.";
	else
		echo -e "\toptional xorg conf (${tegra_xorg_conf}) not found. continue ";
	fi;

	popd > /dev/null 2>&1;
	echo -e -n "\tSync'ing... ";
	sync; sync;	# Paranoid.
	echo "done.";
	umount /dev/loop0 > /dev/null 2>&1;
	losetup -d /dev/loop0 > /dev/null 2>&1;
	rmdir mnt > /dev/null 2>&1;
	echo "System.img built successfully. ";

	echo -n "copying cfgfile(${cfgfile})... ";
	cat ${cfgfile} | sed -e s/size=734003200/size=${rootfs_size}/ -e s/size=471859200/size=${rootfs_size}/ -e s/filename=yaffs2_gnu_system.img/filename=system.img/ -e s/filename=flashboot.img/filename=boot.img/ > flash.cfg;
	if [ $? -ne 0 ]; then
		echo "failed.";
		exit 1;
	fi;
	echo "done.";
else
	echo -n "copying cfgfile(${cfgfile})... ";
	cat ${cfgfile} | sed -e /filename=system.img/d -e /filename=yaffs2_gnu_system.img/d -e s/size=734003200/size=${rootfs_size}/ -e s/size=471859200/size=${rootfs_size}/ -e s/filename=flashboot.img/filename=boot.img/ > flash.cfg; 
	if [ $? -ne 0 ]; then
		echo "failed.";
		exit 1;
	fi;
	echo "done.";
fi;

echo -n "copying bctfile(${bctfile})... ";
cp -f $bctfile flash.bct
if [ $? -ne 0 ]; then
	echo "failed.";
	exit 1;
fi;
echo "done.";

if [ "${bootloader}" != "${nvflashfolder}/fastboot.bin" ]; then
	echo -n "copying bootloader(${bootloader})... ";
	cp -f ${bootloader} ${nvflashfolder}/fastboot.bin
	if [ $? -ne 0 ]; then
		echo "failed.";
		exit 1;
	fi;
	echo "done.";
else
	echo "Existing bootloader(${bootloader}) reused.";
fi;

if [ "$kernel_initrd" != "" -a -f "$kernel_initrd" ]; then
	echo -n "copying initrd(${kernel_initrd})... ";
	cp -f ${kernel_initrd} initrd;
	if [ $? -ne 0 ]; then
		echo "failed.";
		exit 1;
	fi;
	echo "done.";
else
	echo "making zero initrd... ";
	rm -f initrd;
	if [ $? -ne 0 ]; then
		echo "failed.";
		exit 1;
	fi;
	touch initrd;
	if [ $? -ne 0 ]; then
		echo "failed.";
		exit 1;
	fi;
	echo "done.";
fi;

echo -n "Making Boot image... "
./mkbootimg --kernel ${kernel_image} --ramdisk initrd --board "${target_rootdev}" --cmdline "${cmdline}" --output boot.img > /dev/null 2>&1;
if [ $? -ne 0 ]; then
	echo "failed.";
	exit 1;
fi;
echo "done";

echo "*** Flashing target device started. ***"
LD_LIBRARY_PATH=. ./nvflash --bct flash.bct --setbct \
    --configfile flash.cfg --create --bl fastboot.bin --odmdata $odmdata --go
if [ $? -ne 0 ]; then
    echo "Failed to flash ${target_board}."
    exit 2
fi;
popd > /dev/null 2>&1;

echo "*** The target ${target_board} has been flashed successfully. ***"
if [ "${internal_rootdev}" = "true" ]; then
	echo -n "Reset the board to boot from internal eMMC."
else
	echo "Make the target filesystem available to the device and reset the board to boot."
fi;
exit 0;
