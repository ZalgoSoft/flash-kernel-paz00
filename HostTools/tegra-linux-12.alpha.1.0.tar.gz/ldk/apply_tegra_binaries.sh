#!/bin/bash

#
# This script applies the tegra binaries to the rootfs dir in this package
#

# fail on errors
set -e

LDK_DIR=$(cd `dirname $0` && pwd)

if [ -z "${LDK_ROOTFS_DIR}" ] ; then
    LDK_ROOTFS_DIR=${LDK_DIR}/rootfs
    echo "Using default rootfs directory of: ${LDK_ROOTFS_DIR}"
    echo ""
fi

echo "Extracting the NVIDIA user space components to ${LDK_ROOTFS_DIR}"
pushd ${LDK_ROOTFS_DIR}
sudo tar zxpf ${LDK_DIR}/nv_tegra/tegra_bins.tar.gz
popd > /dev/null

echo "Success!"
